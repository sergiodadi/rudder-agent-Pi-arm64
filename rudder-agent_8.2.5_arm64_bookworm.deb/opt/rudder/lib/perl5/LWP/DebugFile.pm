package LWP::DebugFile;

our $VERSION = '6.70';

# legacy stub

1;
